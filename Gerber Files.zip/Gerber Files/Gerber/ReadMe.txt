
Project RUTDevKit-PSoC62:
PCB dimensions 72.2x129.9mm.
4 Layers.
Thickness: 1.55mm FR4.
Mask color : Blue.
Silkscreen color: White.
Finish: Immersion Gold.
Vias: Tented